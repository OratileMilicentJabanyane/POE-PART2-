
package testSide;

import AppSide.Login;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * LoginTest class contains all unit tests for Login class.
 */
public class LoginTest {

    private final String GOOD_USER = "kyl_1";
    private final String GOOD_PASS = "Ch&&sec@ke99!";
    private final String GOOD_PHONE = "+27838968976";
    private final String SUCCESS = "Username successfully captured.\nPassword successfully captured.\nCell phone number successfully added.";

    @Test
    public void testUsernameIsCorrectlyFormatted() {
        Login l = new Login("Kyle", "Smith", GOOD_USER, GOOD_PASS, GOOD_PHONE);
        assertEquals(SUCCESS, l.registerUser());
    }

    @Test
    public void testUsernameIsIncorrectlyFormatted() {
        Login l = new Login("Kyle", "Smith", "bad", GOOD_PASS, GOOD_PHONE);
        assertEquals("Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length.", l.registerUser());
    }

    @Test
    public void testPasswordMeetsComplexityRequirements() {
        Login l = new Login("Kyle", "Smith", GOOD_USER, GOOD_PASS, GOOD_PHONE);
        assertEquals(SUCCESS, l.registerUser());
    }

    @Test
    public void testPasswordDoesNotMeetComplexityRequirements() {
        Login l = new Login("Kyle", "Smith", GOOD_USER, "bad", GOOD_PHONE);
        assertEquals("Password is not correctly formatted, please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.", l.registerUser());
    }

    @Test
    public void testCellPhoneNumberCorrectlyFormatted() {
        Login l = new Login("Kyle", "Smith", GOOD_USER, GOOD_PASS, GOOD_PHONE);
        assertEquals(SUCCESS, l.registerUser());
    }

    @Test
    public void testCellPhoneNumberIncorrectlyFormatted() {
        Login l = new Login("Kyle", "Smith", GOOD_USER, GOOD_PASS, "bad");
        assertEquals("Cell phone number incorrectly formatted or does not contain international code.", l.registerUser());
    }

    @Test
    public void testLoginSuccessful() {
        Login l = new Login("Kyle", "Smith", GOOD_USER, GOOD_PASS, GOOD_PHONE);
        assertTrue(l.loginUser(GOOD_USER, GOOD_PASS));
    }

    @Test
    public void testLoginFailed() {
        Login l = new Login("Kyle", "Smith", GOOD_USER, GOOD_PASS, GOOD_PHONE);
        assertFalse(l.loginUser("x", "y"));
    }

    @Test
    public void testUsernameCorrectlyFormattedBoolean() {
        Login l = new Login("Kyle", "Smith", GOOD_USER, GOOD_PASS, GOOD_PHONE);
        assertTrue(l.checkUserName());
    }

    @Test
    public void testUsernameIncorrectlyFormattedBoolean() {
        Login l = new Login("Kyle", "Smith", "bad", GOOD_PASS, GOOD_PHONE);
        assertFalse(l.checkUserName());
    }

    @Test
    public void testPasswordMeetsComplexityRequirementsBoolean() {
        Login l = new Login("Kyle", "Smith", GOOD_USER, GOOD_PASS, GOOD_PHONE);
        assertTrue(l.checkPasswordComplexity());
    }

    @Test
    public void testPasswordDoesNotMeetComplexityRequirementsBoolean() {
        Login l = new Login("Kyle", "Smith", GOOD_USER, "bad", GOOD_PHONE);
        assertFalse(l.checkPasswordComplexity());
    }

    @Test
    public void testCellPhoneNumberCorrectlyFormattedBoolean() {
        Login l = new Login("Kyle", "Smith", GOOD_USER, GOOD_PASS, GOOD_PHONE);
        assertTrue(l.checkCellPhoneNumber());
    }

    @Test
    public void testCellPhoneNumberIncorrectlyFormattedBoolean() {
        Login l = new Login("Kyle", "Smith", GOOD_USER, GOOD_PASS, "bad");
        assertFalse(l.checkCellPhoneNumber());
    }
}
