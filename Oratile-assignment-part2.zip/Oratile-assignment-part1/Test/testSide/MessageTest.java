package testSide;

import AppSide.Message;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class MessageTest {

    @Test
    public void testMessageLengthSuccess() {
        Message msg = new Message(
                "0012345678",
                0,
                "+27718693002",
                "Hi Mike, can you join us for dinner tonight?"
        );

        assertTrue(msg.checkMessageLength());
    }

    @Test
    public void testMessageLengthFailure() {
        String longMessage = "A".repeat(260);

        Message msg = new Message(
                "0012345678",
                0,
                "+27718693002",
                longMessage
        );

        assertFalse(msg.checkMessageLength());
    }

    @Test
    public void testRecipientNumberCorrectlyFormatted() {
        Message msg = new Message(
                "0012345678",
                0,
                "+27718693002",
                "Hi Mike, can you join us for dinner tonight?"
        );

        assertEquals(1, msg.checkRecipientCell());
    }

    @Test
    public void testRecipientNumberIncorrectlyFormatted() {
        Message msg = new Message(
                "0012345678",
                0,
                "08575975889",
                "Hi Keegan, did you receive the payment?"
        );

        assertEquals(0, msg.checkRecipientCell());
    }

    @Test
    public void testMessageHashCreatedCorrectly() {
        Message msg = new Message(
                "0012345678",
                0,
                "+27718693002",
                "Hi Mike, can you join us for dinner tonight?"
        );

        assertEquals("00:0:HITONIGHT?", msg.getMessageHash());
    }

    @Test
    public void testMessageIDCreated() {
        Message msg = new Message(
                "0012345678",
                0,
                "+27718693002",
                "Test message"
        );

        assertTrue(msg.checkMessageID());
    }

    @Test
    public void testSendMessage() {
        Message msg = new Message(
                "0012345678",
                0,
                "+27718693002",
                "Test message"
        );

        assertEquals("Message successfully sent.", msg.sentMessage(1));
    }

    @Test
    public void testDisregardMessage() {
        Message msg = new Message(
                "0012345678",
                0,
                "+27718693002",
                "Test message"
        );

        assertEquals("Press 0 to delete message.", msg.sentMessage(2));
    }

    @Test
    public void testStoreMessage() {
        Message msg = new Message(
                "0012345678",
                0,
                "+27718693002",
                "Test message"
        );

        assertEquals("Message successfully stored.", msg.sentMessage(3));
    }
}