
package AppSide;

/**
 * Login class provides complete user registration and authentication functionality.
 * Implements validation rules as specified in the assignment document.
 */
public class Login {
    
    // User data members
    private String givenName;
    private String familyName;
    private String chosenUsername;
    private String chosenPassword;
    private String saPhoneNumber;

    /**
     * Constructor to create Login instance with user registration data.
     * 
     * @param givenName User's first name
     * @param familyName User's last name
     * @param chosenUsername Desired username
     * @param chosenPassword Desired password
     * @param saPhoneNumber South African cell phone number
     */
    public Login(String givenName, String familyName, String chosenUsername, String chosenPassword, String saPhoneNumber) {
        this.givenName = givenName;
        this.familyName = familyName;
        this.chosenUsername = chosenUsername;
        this.chosenPassword = chosenPassword;
        this.saPhoneNumber = saPhoneNumber;
    }

    /**
     * Checks if username follows required format.
     * Format requirements: Contains underscore (_) AND length <= 5.
     * 
     * @return true if username valid, false if invalid
     */
    public boolean checkUserName() {
        boolean underscoreFound = chosenUsername.contains("_");
        boolean lengthOkay = chosenUsername.length() <= 5;
        return underscoreFound && lengthOkay;
    }

    /**
     * Checks if password meets all complexity requirements.
     * Requirements: Minimum 8 characters, includes uppercase letter,
     * includes number, includes special character.
     * 
     * @return true if password valid, false if invalid
     */
    public boolean checkPasswordComplexity() {
        boolean hasUpperCase = false;
        boolean hasNumeric = false;
        boolean hasSpecialChar = false;

        // Check minimum length first
        if (chosenPassword.length() < 8) {
            return false;
        }

        // Iterate through password characters
        for (int counter = 0; counter < chosenPassword.length(); counter++) {
            char current = chosenPassword.charAt(counter);

            if (Character.isUpperCase(current)) {
                hasUpperCase = true;
            }
            if (Character.isDigit(current)) {
                hasNumeric = true;
            }
            if (!Character.isLetterOrDigit(current)) {
                hasSpecialChar = true;
            }
        }

        return hasUpperCase && hasNumeric && hasSpecialChar;
    }

    /**
     * Validates South African cell phone number format.
     * Valid format: +27 followed by exactly 9 digits.
     * 
     * @return true if phone number valid, false if invalid
     */
    public boolean checkCellPhoneNumber() {
        // Regular expression for SA phone number validation
        boolean formatCorrect = saPhoneNumber.matches("^\\+27\\d{9}$");
        return formatCorrect;
    }

    /**
     * Processes registration and returns appropriate message.
     * Validates in order: username, password, phone number.
     * 
     * @return Error message for first failure, or success message
     */
    public String registerUser() {
        // Test username condition
        if (!this.checkUserName()) {
            return "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length.";
        }

        // Test password condition
        if (!this.checkPasswordComplexity()) {
            return "Password is not correctly formatted, please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
        }

        // Test phone condition
        if (!this.checkCellPhoneNumber()) {
            return "Cell phone number incorrectly formatted or does not contain international code.";
        }

        // All conditions satisfied
        return "Username successfully captured.\nPassword successfully captured.\nCell phone number successfully added.";
    }

    /**
     * Verifies login credentials against stored registration data.
     * 
     * @param inputUsername Username from login attempt
     * @param inputPassword Password from login attempt
     * @return true if credentials match, false otherwise
     */
    public boolean loginUser(String inputUsername, String inputPassword) {
        boolean usernameMatch = chosenUsername.equals(inputUsername);
        boolean passwordMatch = chosenPassword.equals(inputPassword);
        return usernameMatch && passwordMatch;
    }

    /**
     * Returns login status message based on credential verification.
     * 
     * @param inputUsername Username from login attempt
     * @param inputPassword Password from login attempt
     * @return Welcome message or error message
     */
    public String returnLoginStatus(String inputUsername, String inputPassword) {
        boolean authenticationSuccess = loginUser(inputUsername, inputPassword);
        
        if (authenticationSuccess) {
            String welcomeText = "Welcome " + givenName + ", " + familyName + " it is great to see you again.";
            return welcomeText;
        } else {
            return "Username or password incorrect, please try again.";
        }
    }
}