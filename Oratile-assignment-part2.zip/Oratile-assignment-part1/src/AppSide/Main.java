package AppSide;

import java.util.Random;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner inputReader = new Scanner(System.in);

        System.out.println("===== REGISTRATION =====");

        System.out.print("Enter first name: ");
        String firstNameInput = inputReader.nextLine();

        System.out.print("Enter last name: ");
        String lastNameInput = inputReader.nextLine();

        System.out.print("Enter username: ");
        String usernameInput = inputReader.nextLine();

        System.out.print("Enter password: ");
        String passwordInput = inputReader.nextLine();

        System.out.print("Enter South African cell phone number (include +27): ");
        String phoneInput = inputReader.nextLine();

        Login userLogin = new Login(firstNameInput, lastNameInput, usernameInput, passwordInput, phoneInput);

        String regResult = userLogin.registerUser();
        System.out.println(regResult);

        boolean userValid = userLogin.checkUserName();
        boolean passValid = userLogin.checkPasswordComplexity();
        boolean phoneValid = userLogin.checkCellPhoneNumber();

        if (userValid == true && passValid == true && phoneValid == true) {

            System.out.println();
            System.out.println("===== LOGIN =====");

            System.out.print("Enter username: ");
            String loginUserInput = inputReader.nextLine();

            System.out.print("Enter password: ");
            String loginPassInput = inputReader.nextLine();

            System.out.println(userLogin.returnLoginStatus(loginUserInput, loginPassInput));

            if (userLogin.loginUser(loginUserInput, loginPassInput)) {

                System.out.println("Welcome to QuickChat.");

                int menuChoice = 0;

                while (menuChoice != 3) {

                    System.out.println();
                    System.out.println("===== QUICKCHAT MENU =====");
                    System.out.println("1) Send Messages");
                    System.out.println("2) Show recently sent messages");
                    System.out.println("3) Quit");
                    System.out.print("Choose an option: ");

                    menuChoice = inputReader.nextInt();
                    inputReader.nextLine();

                    switch (menuChoice) {

                        case 1:
                            System.out.print("How many messages would you like to send? ");
                            int numberOfMessages = inputReader.nextInt();
                            inputReader.nextLine();

                            for (int count = 1; count <= numberOfMessages; count++) {

                                System.out.println();
                                System.out.println("===== MESSAGE " + count + " =====");

                                String messageID = generateMessageID();

                                System.out.println("Message ID generated: " + messageID);

                                System.out.print("Enter recipient number: ");
                                String recipient = inputReader.nextLine();

                                System.out.print("Enter message: ");
                                String messageText = inputReader.nextLine();

                                Message message = new Message(messageID, count, recipient, messageText);

                                if (!message.checkMessageID()) {
                                    System.out.println("Message ID is invalid.");
                                    continue;
                                }

                                if (message.checkRecipientCell() == 1) {
                                    System.out.println("Cell phone number successfully captured.");
                                } else {
                                    System.out.println("Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.");
                                    continue;
                                }

                                if (message.checkMessageLength()) {
                                    System.out.println("Message ready to send.");
                                } else {
                                    int exceededBy = messageText.length() - 250;
                                    System.out.println("Message exceeds 250 characters by " + exceededBy + ", please reduce the size.");
                                    continue;
                                }

                                System.out.println();
                                System.out.println("Choose one of the following options:");
                                System.out.println("1) Send Message");
                                System.out.println("2) Disregard Message");
                                System.out.println("3) Store Message");
                                System.out.print("Enter option: ");

                                int sendOption = inputReader.nextInt();
                                inputReader.nextLine();

                                System.out.println(message.sentMessage(sendOption));

                                System.out.println();
                                System.out.println("===== MESSAGE DETAILS =====");
                                System.out.println(message.printMessage());
                            }

                            System.out.println();
                            System.out.println("Total messages sent: " + Message.returnTotalMessages());
                            break;

                        case 2:
                            System.out.println("Coming Soon.");
                            break;

                        case 3:
                            System.out.println("Exiting QuickChat.");
                            break;

                        default:
                            System.out.println("Invalid option selected.");
                    }
                }
            }
        }

        inputReader.close();
    }

    public static String generateMessageID() {
        Random random = new Random();

        long number = 1000000000L + (long) (random.nextDouble() * 9000000000L);

        return String.valueOf(number);
    }
}